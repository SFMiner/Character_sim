# Dialogue Simulator - Godot 4.5 Project

A deterministic character dialogue simulator implementing the v4.0 spec with extensible interfaces for future personality/drive systems.

## Quick Start

1. Open in Godot 4.5
2. Run `main.tscn` (LLM-type character: Archivist-7)
3. Or run `human_npc.tscn` (Human-type character: Old Marcus)
4. Try these queries:
   - "Where is the blacksmith?"
   - "Where is the blacksmieth?" (typo - still works!)
   - "Who is the king?"
   - "Who are you?" (self-knowledge)
   - "Tell me about the tavern"
   - "What about magic?" (forbidden topic for Archivist-7)
   - Ask a follow-up: "What about it?" (tests coreference)

## Project Structure

```
dialogue_sim/
├── knowledge/                    # Epistemic backend
│   ├── fact_resource.gd         # Semantic content (never dialogue-ready)
│   ├── world_knowledge_resource.gd  # Canonical truth archive
│   ├── npc_memory_resource.gd   # Subjective beliefs (duplicated per NPC)
│   ├── knowledge_adapter.gd     # Epistemic firewall - belief overrides truth
│   └── world_knowledge_autoload.gd  # Singleton with sample facts
│
├── dialogue/                     # Dialogue pipeline
│   ├── speech_act_interpreter.gd   # Classifies input type
│   ├── context_state.gd            # Coreference resolution
│   ├── decision_gate.gd            # Decides WHAT to do (share/refuse/deflect)
│   ├── skeleton_engine.gd          # Selects response structure
│   ├── template_rewriter.gd        # Safe variation only
│   ├── formatter.gd                # Final assembly
│   ├── dialogue_manager.gd         # Pipeline orchestrator
│   ├── character_node.gd           # Main NPC node
│   ├── character_profile.gd        # Static character definition
│   └── npc_state.gd                # Runtime mutable state
│
├── ui/
│   └── dialogue_ui.gd           # Simple test UI
│
├── data/
│   └── skeletons.json           # Response structure templates
│
├── main.tscn                    # LLM character scene
├── human_npc.tscn               # Human character scene
└── project.godot
```

## Pipeline Flow

```
Player Input
     ↓
SpeechActInterpreter (classify: ASK_ABOUT, REQUEST_HELP, etc.)
     ↓
ContextState (resolve "it", "they" → recent subject)
     ↓
KnowledgeAdapter (query belief, not truth)
     ↓
DecisionGate (decide: SHARE, REFUSE_FORBIDDEN, REFUSE_UNKNOWN, etc.)
     ↓
SkeletonEngine (select preamble/body/postamble structure)
     ↓
Formatter (assemble with content)
     ↓
TemplateRewriter (safe variation)
     ↓
Response
```

## Key Design Principles

### 1. Belief Overrides Truth
If an NPC has misinformation, they speak the false belief:
```gdscript
# In npc_memory_resource:
misinformation = {4: "the King | is named | Aldric the Wise"}  # Truth: Aldric III
```

### 2. Facts Are Never Dialogue
Raw facts like `"blacksmith | is located in | Market District"` are transformed by the pipeline - they never appear directly in output.

### 3. LLM vs Human Voice
- **LLM type**: Structured output, hedging, policy-style refusals
- **Human type**: Direct, terse, natural speech patterns

### 4. Memory Duplication
Each NPC instance gets a **duplicate** of their memory resource. Changes to one NPC don't affect others.

## Learning System (Phase 1)

NPCs can now learn facts dynamically through various mechanisms:

### Source Types
| Type | Description | Generation |
|------|-------------|------------|
| `INNATE` | Always knew (initial seeding) | 0 |
| `WITNESSED` | Saw it firsthand | 0 |
| `TOLD` | Someone told them | +1 per retelling |
| `ENVIRONMENTAL` | Absorbed from location | 0 |
| `RUMOR` | Overheard, unverified | 3 (distant hearsay) |

### Learning API (CharacterNode)
```gdscript
# Tell NPC a fact (social learning)
npc.tell_fact(fact_id, "speaker_name", speaker_confidence, generation)

# NPC witnesses something directly
npc.witness_fact(fact_id, clarity)

# NPC hears a rumor
npc.hear_rumor(fact_id, strength)

# Check what NPC knows
npc.knows_fact(fact_id)  # bool
npc.get_belief_strength(fact_id)  # float or -1
npc.get_fact_source(fact_id)  # Dictionary with provenance
```

### Hearsay Degradation
Knowledge degrades with each retelling:
- Generation 0 (firsthand): 100% strength
- Generation 1 (secondhand): 70% strength
- Generation 2: 49% strength
- Generation 3+: continues decay

### Trust System
```gdscript
# NPCs have trust levels for other entities
npc.get_trust("merchant_bob")  # Returns 0.0-1.0
npc.set_trust("merchant_bob", 0.8)

# Trust affects social learning strength
# strength = trust × speaker_confidence × hearsay_penalty
```

### Provenance Tracking
Each belief now tracks:
- `type`: How it was learned (SourceType enum)
- `source_id`: Who told them (if TOLD)
- `generation`: Hearsay depth
- `learned_at`: Timestamp
- `reinforcements`: Times confirmed

## Extension Points

Every component has documented extension points for future features:

| Component | Extension | What It Enables |
|-----------|-----------|-----------------|
| `FactResource` | granularity, prerequisites | Knowledge gating |
| `NPCMemoryResource` | sources | Provenance tracking ✓ (implemented) |
| `CharacterProfile` | curiosity, default_trust | Learning traits ✓ (implemented) |
| `NPCState` | location, trust_levels | Dynamic learning ✓ (implemented) |
| `LearningSystem` | calculate_* functions | Centralized learning math ✓ (implemented) |
| `DecisionGate` | drive evaluation | Decision-making based on self-interest |
| `SkeletonEngine.get_candidates()` | personality scoring | Multi-candidate selection |

To enable an extension, search for `## EXTENSION POINT` in the code and uncomment the relevant sections.

## Testing Coreference

1. Ask: "Where is the blacksmith?"
2. Then ask: "What about it?" or "Tell me more about that"
3. The system should resolve "it/that" to "blacksmith"

## Testing Forbidden Topics

Archivist-7 refuses to discuss magic:
- "Tell me about magic" → Refusal skeleton
- "What spells do you know?" → Refusal skeleton

## Testing Misinformation

Old Marcus believes the king is named "Aldric the Wise" (truth: Aldric III):
- Ask Old Marcus: "Who is the king?"
- He'll give the wrong name with confidence

## Debug Mode

Click the "Debug" button to see:
- Speech act classification
- Subject extraction
- Coreference resolution
- Knowledge lookup results
- Decision made

## Sample Facts in World Knowledge

| ID | Tags | Content |
|----|------|---------|
| 1 | location, blacksmith | the blacksmith is located in the Market District |
| 2 | location, tavern | The Rusty Sword tavern stands near the city gates |
| 3 | location, temple | the Temple of Dawn overlooks the city from the eastern hill |
| 4 | person, king | the King is named Aldric III |
| 5 | person, captain | the Captain of the Guard is Helena Ironhand |
| 6 | person, merchant | the Merchant Guild is led by Master Tobias |
| 7 | history, war | The Great War ended one hundred years ago |
| 8 | legend, dragon | the last dragon was slain by the First King |
| 9 | secret, king | King Aldric suffers from a wasting sickness |
| 10 | identity, old marcus | I am Old Marcus, a veteran of the city watch |
| 11 | identity, archivist-7 | I am Archivist-7, a knowledge repository system |

## Features

### Fuzzy Matching (Typo Tolerance)
The system uses Levenshtein distance to handle common misspellings:
- "blacksmieth" → matches "blacksmith"
- "tavrn" → matches "tavern"
- Edit distance of 2 or less is accepted (1 for short words)

### Self-Knowledge
NPCs can answer "Who are you?" questions:
- Recognizes patterns like "who are you", "what's your name", "tell me about yourself"
- Maps to the NPC's identity fact in their memory

### Forbidden Topics (Fixed)
Forbidden topic matching now works correctly:
- Only triggers when the forbidden phrase appears in the query
- "king" no longer triggers "king illness" as forbidden

## License

This is a demonstration project for educational purposes.
